
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="breadcrumb-main user-member justify-content-sm-between ">
            <div class=" d-flex flex-wrap justify-content-center breadcrumb-main__wrapper">
                <div class="d-flex align-items-center user-member__title justify-content-center mr-sm-25">
                    <h4 class="text-capitalize fw-500 breadcrumb-title">Email list</h4>
                    <span class="sub-title ml-sm-25 pl-sm-25"><?php echo e(count($emails)); ?> Emails</span>
                </div>
            </div>
        </div>

    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="userDatatable table-striped global-shadow border p-30 bg-white radius-xl w-100 mb-30">
        <div id="filter-form-container"></div>
            <div class="table-responsive">
                <table class="table mb-0 border table-borderless adv-table"  data-sorting="true" data-filter-container="#filter-form-container" data-paging-current="1" data-paging-position="right" data-paging-size="10">
                    <thead>
                        <tr class="userDatatable-header">
                            <th>                               
                                <span class="userDatatable-title">email address</span>
                            </th>
                            <th class="text-center">                               
                                <span class="userDatatable-title">subject</span>
                            </th>
                            <th class="text-center">
                                <span class="userDatatable-title">message</span>
                            </th>
                            <th class="text-center">
                                <span class="userDatatable-title">attachment</span>
                            </th>
                            <th class="text-center">
                                <span class="userDatatable-title">user</span>
                            </th> 
                            <th class="text-center">
                                <span class="userDatatable-title">date</span>
                            </th>
                            <th class="text-center">
                                <span class="userDatatable-title">status</span>
                            </th>
                            <th class="text-center">                               
                                <span class="userDatatable-title">reference</span>                                      
                            </th>
                        </tr>
                    </thead>
                   <tbody>
                    <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    <td>
                        <div class="">
                            <?php echo e($item->to); ?>                                  
                        </div>
                    </td>
                    <td>
                        <div class="text-wrap">
                            <?php echo e($item->subject); ?>

                        </div>
                    </td>
                    <td>
                        <div class="userDatatable-content text-wrap">
                            <?php echo e($item->message); ?>

                        </div>
                    </td>
                    <td class="text-center">
                        <div class="userDatatable-content">
                            <?php if($item->attachment): ?>
                            <?php echo e($item->user->attachment); ?>

                            <?php endif; ?>
                        </div>
                    </td>   
                    <td class="text-center">
                        <div class="userDatatable-content">
                            <?php if($item->user): ?>
                            <?php echo e($item->user->name); ?>

                            <?php endif; ?>
                        </div>
                    </td>   
                    <td class="text-center">
                        <div class="userDatatable-content">
                            <?php echo e($item->created_at->format('d/m/Y H:i')); ?>

                        </div>
                    </td>
                    <td class="text-center">
                        <?php if($item->sent == true): ?>
                        <div class="userDatatable-content d-inline-block">
                            <span class="bg-opacity-success  color-success rounded-pill userDatatable-content-status active">sent</span>
                        </div>
                        <?php elseif($item->sent == false): ?>
                        <div class="userDatatable-content d-inline-block">
                            <span class="bg-opacity-danger  color-danger rounded-pill userDatatable-content-status">not sent</span>
                        </div>
                        <?php else: ?>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">  
                        <div class="userDatatable-content d-inline-block">
                            <?php if($item->reference): ?>
                            <span class="bg-opacity-warning  color-warning rounded-pill userDatatable-content-status active"><?php echo e($item->reference); ?></span>
                            <?php endif; ?>
                         </div>
                    </td>
                </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                </table>
            </div>           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Desktop\laravel\afyaplug\resources\views/notifications/emails.blade.php ENDPATH**/ ?>